# Free TV Hub - custom setup and navigation hub for Kodi 21 (Omega).
# Installs verified free add-ons from their own repositories and provides
# a simple menu. Contains no third-party code and no content.
import os
import sys
import urllib.request
import zipfile
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

SLYGUY_REPO_ZIP_URL = 'https://slyguy.uk/repository.slyguy.zip'
REPO_ID_SETTING = 'slyguy_repo_id'
REPO_ID_FALLBACK = 'repository.slyguy'

# Add-ons installed by Step 2. Only entries verified at their owning source
# (present in the official Kodi 21 repo, or in the SlyGuy repo listing with
# author-documented free/no-login capability).
OFFICIAL_ADDONS = [
    ('script.trakt', 'Trakt'),
    ('pvr.iptvsimple', 'PVR IPTV Simple Client'),
    ('plugin.video.themoviedb.helper', 'TheMovieDb Helper'),
    ('plugin.video.documentaryheaven', 'Documentary Heaven'),
]
SLYGUY_ADDONS = [
    ('slyguy.pluto.tv.provider', 'Pluto TV'),
    ('slyguy.samsung.tv.plus', 'Samsung TV Plus'),
    ('slyguy.plex.live', 'Plex Live'),
    ('slyguy.pbs.live', 'PBS Live'),
    ('plugin.program.iptv.merge', 'IPTV Merge'),
]
SERVICES = [
    ('slyguy.pluto.tv.provider', 'Pluto TV - live channels'),
    ('slyguy.samsung.tv.plus', 'Samsung TV Plus - live channels'),
    ('slyguy.plex.live', 'Plex Live - live channels'),
    ('slyguy.pbs.live', 'PBS Live - local stations'),
    ('plugin.video.documentaryheaven', 'Documentary Heaven - documentaries'),
]


def is_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except Exception:
        return False


def add_item(label, action):
    url = '%s?action=%s' % (BASE_URL, action)
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, False)


def show_menu():
    add_item('Step 1: Get the SlyGuy repository', 'get_repo')
    add_item('Step 2: Install the free-TV add-ons', 'install_addons')
    add_item('Live TV guide', 'tv_guide')
    add_item('Live TV channels', 'tv_channels')
    for addon_id, label in SERVICES:
        if is_installed(addon_id):
            add_item(label, 'open:%s' % addon_id)
    if is_installed('plugin.video.themoviedb.helper'):
        add_item('Browse and search the TMDb catalog (TMDb Helper)',
                 'open:plugin.video.themoviedb.helper')
    if is_installed('script.trakt'):
        add_item('Trakt: sign in and settings', 'trakt_settings')
    xbmcplugin.endOfDirectory(HANDLE)


def read_repo_id(zip_path):
    """Read the repository add-on's real id from the downloaded zip."""
    try:
        with zipfile.ZipFile(zip_path) as archive:
            for name in archive.namelist():
                if name.endswith('addon.xml'):
                    root = ET.fromstring(archive.read(name))
                    repo_id = root.get('id')
                    if repo_id:
                        return repo_id
    except Exception:
        pass
    return None


def get_repo():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.isdir(profile):
        os.makedirs(profile)
    dest = os.path.join(profile, 'repository.slyguy.zip')
    try:
        urllib.request.urlretrieve(SLYGUY_REPO_ZIP_URL, dest)
    except Exception as err:
        xbmcgui.Dialog().ok('Free TV Hub',
                            'Download failed. Check the internet connection and try again.\n%s' % err)
        return
    repo_id = read_repo_id(dest)
    if repo_id:
        ADDON.setSetting(REPO_ID_SETTING, repo_id)
    xbmcgui.Dialog().ok(
        'Free TV Hub',
        'SlyGuy repository downloaded. In the next window, open "Profile directory" '
        '(or "Home folder", then "userdata"), then "addon_data", then "%s", '
        'and select repository.slyguy.zip' % ADDON_ID)
    xbmc.executebuiltin('InstallFromZip')


def repo_present():
    candidates = [ADDON.getSetting(REPO_ID_SETTING), REPO_ID_FALLBACK]
    return any(is_installed(c) for c in candidates if c)


def install_addons():
    if not repo_present():
        proceed = xbmcgui.Dialog().yesno(
            'Free TV Hub',
            'Could not confirm the SlyGuy repository is installed. Run Step 1 first '
            'for the live-TV add-ons.\n\nContinue anyway? (Official add-ons will still work.)')
        if not proceed:
            return
    todo = [(a, n) for a, n in OFFICIAL_ADDONS + SLYGUY_ADDONS if not is_installed(a)]
    if not todo:
        xbmcgui.Dialog().ok('Free TV Hub', 'Everything on the list is already installed.')
        return
    results = []
    for addon_id, name in todo:
        if not xbmcgui.Dialog().yesno('Free TV Hub',
                                      'Install %s?\n\nKodi may show its own prompt - please accept it.' % name):
            results.append((name, 'skipped'))
            continue
        xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
        installed = False
        for _ in range(15):
            if is_installed(addon_id):
                installed = True
                break
            xbmc.sleep(2000)
        results.append((name, 'installed' if installed
                        else 'not confirmed - open Add-ons > My add-ons to check'))
    summary = '\n'.join('%s: %s' % (name, status) for name, status in results)
    xbmcgui.Dialog().textviewer('Free TV Hub - results', summary)


def router():
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        for part in sys.argv[2].lstrip('?').split('&'):
            if '=' in part:
                key, value = part.split('=', 1)
                params[key] = value
    action = params.get('action', '')
    if action == 'get_repo':
        get_repo()
    elif action == 'install_addons':
        install_addons()
    elif action == 'tv_guide':
        xbmc.executebuiltin('ActivateWindow(tvguide)')
    elif action == 'tv_channels':
        xbmc.executebuiltin('ActivateWindow(tvchannels)')
    elif action == 'trakt_settings':
        xbmc.executebuiltin('Addon.OpenSettings(script.trakt)')
    elif action.startswith('open:'):
        xbmc.executebuiltin('RunAddon(%s)' % action[5:])
    else:
        show_menu()


router()
